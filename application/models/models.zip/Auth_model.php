<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth_model extends CI_Model {

	// 

}

/* End of file Auth_model.php */
/* Location: ./application/models/Auth_model.php */